import doctest
doctest.testfile('README.rst', verbose=False)
